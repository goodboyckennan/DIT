NOTE:Some of the codes may be incorrect or unfinished 
so make sure you READ THE COMMENTS for clarification.